# Evaluation report

## Dataset and methodology

The manually reviewed set contains 9 synthetic resume/job pairs. Labels were assigned before scoring and are a small sanity check, not a benchmark. Each pair was scored with the same comparison function used by the app against the full corresponding description in data/sample_jobs.csv.

**Observed scoring method:** sentence-transformer
**High-vs-low mean ordering check:** PASS (high mean=82.96, low mean=60.53)

## Pair scores

| Case | Reviewed label | Score | Method |
|---|---|---:|---|
| E-001 | high | 77.91 | sentence-transformer |
| E-002 | high | 84.24 | sentence-transformer |
| E-003 | high | 85.11 | sentence-transformer |
| E-004 | low | 52.89 | sentence-transformer |
| E-005 | low | 63.51 | sentence-transformer |
| E-006 | high | 83.24 | sentence-transformer |
| E-007 | low | 65.20 | sentence-transformer |
| E-008 | high | 84.30 | sentence-transformer |
| E-009 | medium | 80.92 | sentence-transformer |

## Limitations

This is a tiny synthetic sanity set and does not estimate hiring probability, fairness, generalization, or calibrated suitability. A larger, independently reviewed set should be used for serious evaluation.

## Skills review

The curated skills dictionary is intentionally transparent and maintainable. Review edge cases such as Java versus JavaScript, punctuation-heavy names such as C++, and aliases such as sklearn/scikit-learn. A missed skill can reflect resume wording or dictionary coverage; it is not evidence that a candidate lacks the skill.
