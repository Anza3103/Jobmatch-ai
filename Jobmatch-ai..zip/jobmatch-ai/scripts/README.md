Run `python scripts/run_evaluation.py` from the repository root to score the manually reviewed synthetic evaluation set and update `evaluation/evaluation_report.md` with the observed local results.
