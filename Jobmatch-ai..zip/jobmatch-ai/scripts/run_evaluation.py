"""Run the small reviewed evaluation set and update evaluation_report.md."""

from __future__ import annotations

from pathlib import Path
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.similarity import compare_texts

DATA = ROOT / "evaluation" / "evaluation_data.csv"
REPORT = ROOT / "evaluation" / "evaluation_report.md"


def main() -> None:
    frame = pd.read_csv(DATA)
    jobs = pd.read_csv(ROOT / "data" / "sample_jobs.csv").fillna("")
    rows = []
    for _, row in frame.iterrows():
        matches = jobs.loc[jobs["job_id"] == row["job_id"], "description"]
        if matches.empty:
            raise ValueError(f"Unknown job_id in evaluation data: {row['job_id']}")
        result = compare_texts(row["resume_text"], matches.iloc[0])
        rows.append({"case_id": row["case_id"], "label": row["reviewed_label"], "score": result.score, "method": result.method})
    scored = pd.DataFrame(rows)
    grouped = scored.groupby("label")["score"].mean().to_dict()
    high_low_ok = grouped.get("high", 0) > grouped.get("low", 0)
    lines = [
        "# Evaluation report",
        "",
        "## Dataset and methodology",
        "",
        "The manually reviewed set contains 9 synthetic resume/job pairs. Labels were assigned before scoring and are a small sanity check, not a benchmark. Each pair was scored with the same comparison function used by the app against the full corresponding description in data/sample_jobs.csv.",
        "",
        f"**Observed scoring method:** {', '.join(sorted(scored['method'].unique()))}",
        f"**High-vs-low mean ordering check:** {'PASS' if high_low_ok else 'FAIL'} (high mean={grouped.get('high', 0):.2f}, low mean={grouped.get('low', 0):.2f})",
        "",
        "## Pair scores",
        "",
        "| Case | Reviewed label | Score | Method |",
        "|---|---|---:|---|",
    ]
    lines.extend(f"| {r.case_id} | {r.label} | {r.score:.2f} | {r.method} |" for r in scored.itertuples())
    lines += [
        "",
        "## Limitations",
        "",
        "This is a tiny synthetic sanity set and does not estimate hiring probability, fairness, generalization, or calibrated suitability. A larger, independently reviewed set should be used for serious evaluation.",
        "",
        "## Skills review",
        "",
        "The curated skills dictionary is intentionally transparent and maintainable. Review edge cases such as Java versus JavaScript, punctuation-heavy names such as C++, and aliases such as sklearn/scikit-learn. A missed skill can reflect resume wording or dictionary coverage; it is not evidence that a candidate lacks the skill.",
    ]
    REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(scored.to_string(index=False))
    print(f"Updated {REPORT}")


if __name__ == "__main__":
    main()
