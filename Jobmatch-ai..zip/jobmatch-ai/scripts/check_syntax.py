"""Compile all project Python files without running the Streamlit app."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for path in sorted(ROOT.rglob("*.py")):
    if ".venv" in path.parts:
        continue
    compile(path.read_text(encoding="utf-8"), str(path), "exec")
    print(f"OK {path.relative_to(ROOT)}")
