# Sample job dataset

`sample_jobs.csv` contains 32 synthetic job records created specifically for this portfolio project. They are not real vacancies, do not represent current openings, and should not be used as employment-market evidence.

Each record includes a job ID, title, role category, required and preferred skills, experience level, a short description, and provenance. The descriptions are intentionally realistic enough to exercise the matching pipeline while remaining clearly labeled as synthetic.
