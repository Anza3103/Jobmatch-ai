import json

from src.report_generator import build_report, report_csv, report_json


MATCH = {
    "job_id": "JM-001",
    "job_title": "AI Engineer Intern",
    "semantic_similarity_score": 82.5,
    "similarity_method": "lexical-fallback",
    "resume_skills": ["Python"],
    "required_found": ["Python"],
    "missing_required": ["PyTorch"],
    "missing_preferred": ["Docker"],
    "match_summary": "Example summary",
    "relevant_passages": ["Python project"],
    "provenance": "Synthetic sample data",
}


def test_report_omits_resume_by_default():
    report = build_report(MATCH, resume_text="private resume")
    assert "resume_text" not in report
    assert b"private resume" not in report_json(MATCH, resume_text="private resume")


def test_report_can_explicitly_include_resume():
    payload = json.loads(report_json(MATCH, include_resume_text=True, resume_text="private resume"))
    assert payload["resume_text"] == "private resume"


def test_csv_has_expected_fields():
    csv = report_csv(MATCH).decode("utf-8")
    assert "job_title" in csv
    assert "missing_required_skills" in csv
    assert "AI Engineer Intern" in csv
