import numpy as np
import pytest

from src.similarity import SimilarityResult, compare_texts, cosine_similarity, cosine_to_score


def test_cosine_similarity_known_vectors():
    assert cosine_similarity([1, 0], [1, 0]) == 1.0
    assert cosine_similarity([1, 0], [0, 1]) == 0.0
    assert cosine_similarity([0, 0], [1, 0]) == 0.0


def test_cosine_score_is_bounded():
    assert cosine_to_score(-1) == 0.0
    assert cosine_to_score(0) == 50.0
    assert cosine_to_score(1) == 100.0


def test_empty_compare_is_safe():
    result = compare_texts("", "Python")
    assert isinstance(result, SimilarityResult)
    assert result.score == 0.0
    assert result.method == "empty-input"


def test_lexical_fallback_is_reproducible(monkeypatch):
    # False is the explicit no-model sentinel, so no network/model load is needed.
    first = compare_texts("Python Pandas project", "Python data project", model=False)
    second = compare_texts("Python Pandas project", "Python data project", model=False)
    assert first.method == "lexical-fallback"
    assert first.score == second.score
    assert 0 <= first.score <= 100


def test_cosine_accepts_numpy_arrays():
    assert cosine_similarity(np.array([1.0, 2.0]), np.array([1.0, 2.0])) == pytest.approx(1.0)
