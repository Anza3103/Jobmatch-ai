import pandas as pd

from src.job_ranker import rank_jobs
from src.similarity import SimilarityResult


def fake_similarity(resume: str, description: str) -> SimilarityResult:
    score = 90.0 if "python" in description.lower() else 20.0
    return SimilarityResult(score=score, raw_cosine=None, method="test")


def test_jobs_are_ranked_by_score_then_skill_coverage():
    jobs = pd.DataFrame(
        [
            {"job_id": "low", "job_title": "Low", "role_category": "A", "required_skills": "SQL", "preferred_skills": "", "description": "SQL reporting"},
            {"job_id": "high", "job_title": "High", "role_category": "A", "required_skills": "Python", "preferred_skills": "Git", "description": "Python services"},
        ]
    )
    ranked = rank_jobs("Python project", jobs, similarity_fn=fake_similarity)
    assert ranked.iloc[0]["job_id"] == "high"
    assert ranked.iloc[0]["required_found_count"] == 1
    assert ranked.iloc[0]["missing_required_count"] == 0
