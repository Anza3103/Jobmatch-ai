from io import BytesIO

import pytest

from src.resume_parser import ResumeParseError, extract_text_from_file, supported_extension


def test_supported_extensions():
    assert supported_extension("resume.PDF") == ".pdf"
    assert supported_extension("resume.docx") == ".docx"
    assert supported_extension("resume.txt") == ""


def test_invalid_pdf_is_reported():
    with pytest.raises(ResumeParseError, match="invalid or unreadable"):
        extract_text_from_file(b"not a pdf", "resume.pdf")


def test_empty_upload_is_reported():
    with pytest.raises(ResumeParseError, match="empty"):
        extract_text_from_file(BytesIO(b""), "resume.docx")


def test_unsupported_file_is_reported():
    with pytest.raises(ResumeParseError, match="PDF or DOCX"):
        extract_text_from_file(b"hello", "resume.txt")
