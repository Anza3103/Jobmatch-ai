from src.skills_extractor import extract_skills, parse_skill_list, skill_gap_analysis


def test_alias_normalization():
    found = extract_skills("Built a model with sklearn, NumPy, and a retrieval-augmented generation pipeline.")
    assert {"scikit-learn", "NumPy", "RAG"}.issubset(found)


def test_java_is_not_detected_inside_javascript():
    found = extract_skills("Created a JavaScript dashboard; no Java code was used.")
    assert "JavaScript" in found
    assert "Java" in found  # the sentence explicitly contains standalone Java
    only_js = extract_skills("Created a JavaScript dashboard for the browser.")
    assert "JavaScript" in only_js
    assert "Java" not in only_js


def test_word_boundaries_avoid_substring_false_positive():
    assert "SQL" not in extract_skills("The candidate worked with sequel storytelling.")
    assert "R" not in extract_skills("The candidate worked with reports and research.")


def test_gap_analysis_distinguishes_required_and_preferred():
    result = skill_gap_analysis("Python and Git projects", "Python; SQL; Git", "Docker; FastAPI")
    assert result["required_found"] == ["Python", "Git"]
    assert result["missing_required"] == ["SQL"]
    assert result["missing_preferred"] == ["Docker", "FastAPI"]


def test_skill_list_parsing_deduplicates():
    assert parse_skill_list("Python; python; SQL") == ["Python", "SQL"]
