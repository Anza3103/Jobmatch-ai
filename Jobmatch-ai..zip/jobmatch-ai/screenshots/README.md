# Screenshots

Place genuine screenshots of the running Streamlit application in this folder before publishing the repository. The source project can run without screenshots; this placeholder prevents the folder from disappearing in Git.
