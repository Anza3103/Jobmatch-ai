"""Rule-based, non-fabricating resume recommendations."""

from __future__ import annotations


def generate_recommendations(match: dict) -> list[str]:
    recommendations: list[str] = []
    for skill in match.get("missing_required", []):
        recommendations.append(
            f"If you genuinely have {skill} experience, make it explicit in a project or experience bullet; otherwise, consider learning it rather than claiming proficiency."
        )
    for skill in match.get("missing_preferred", [])[:4]:
        recommendations.append(
            f"Consider a small, honest project using {skill} if it is relevant to your goals, then describe what you built and learned."
        )
    if match.get("required_found"):
        recommendations.append(
            "Move the strongest matched skills closer to the top of the resume and connect each one to evidence such as a project, course, or measurable result."
        )
    if match.get("relevant_passages"):
        recommendations.append(
            "Rewrite the most relevant bullets with an action, the technical method, and a measurable outcome only when you can substantiate the number."
        )
    if not recommendations:
        recommendations.append(
            "Add concise project evidence that shows the tools you used, your contribution, and the result; do not add skills you cannot support."
        )
    return recommendations
