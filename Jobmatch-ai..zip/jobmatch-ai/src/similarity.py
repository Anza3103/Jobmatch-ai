"""Similarity calculations and score interpretation."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .embeddings import EmbeddingModelError, encode_texts, lexical_similarity
from .text_preprocessing import clean_for_embedding


@dataclass(frozen=True)
class SimilarityResult:
    score: float
    raw_cosine: float | None
    method: str


def cosine_similarity(vector_a, vector_b) -> float:
    """Calculate cosine similarity without hiding zero-vector behavior."""
    a = np.asarray(vector_a, dtype=float).reshape(-1)
    b = np.asarray(vector_b, dtype=float).reshape(-1)
    denominator = float(np.linalg.norm(a) * np.linalg.norm(b))
    if denominator == 0:
        return 0.0
    return float(np.dot(a, b) / denominator)


def cosine_to_score(raw_cosine: float) -> float:
    """Scale cosine similarity from [-1, 1] to a bounded [0, 100] display score."""
    return round(max(0.0, min(100.0, (float(raw_cosine) + 1.0) * 50.0)), 2)


def compare_texts(text_a: str, text_b: str, model=None) -> SimilarityResult:
    """Compare two texts using local embeddings, falling back to lexical overlap."""
    left, right = clean_for_embedding(text_a), clean_for_embedding(text_b)
    if not left or not right:
        return SimilarityResult(score=0.0, raw_cosine=None, method="empty-input")
    try:
        vectors = encode_texts([left, right], model=model)
        raw = cosine_similarity(vectors[0], vectors[1])
        return SimilarityResult(score=cosine_to_score(raw), raw_cosine=raw, method="sentence-transformer")
    except (EmbeddingModelError, ImportError, OSError, RuntimeError, ValueError):
        raw = lexical_similarity(left, right)
        return SimilarityResult(score=round(raw * 100.0, 2), raw_cosine=None, method="lexical-fallback")
