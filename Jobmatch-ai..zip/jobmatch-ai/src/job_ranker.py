"""Rank sample jobs against a resume and create evidence-based summaries."""

from __future__ import annotations

import re
from typing import Callable

import pandas as pd

from .similarity import SimilarityResult, compare_texts
from .skills_extractor import skill_gap_analysis


def relevant_passages(resume_text: str, skills: list[str], limit: int = 3) -> list[str]:
    """Return resume paragraphs containing the most matched skill terms."""
    passages = [part.strip() for part in re.split(r"\n\s*\n|(?<=[.!?])\s+", resume_text or "") if part.strip()]
    if not passages:
        return []
    scored = []
    lowered_skills = [skill.lower() for skill in skills]
    for index, passage in enumerate(passages):
        lower = passage.lower()
        score = sum(1 for skill in lowered_skills if skill in lower)
        scored.append((score, -index, passage))
    scored.sort(reverse=True)
    return [passage for score, _, passage in scored[:limit] if score > 0] or passages[:limit]


def build_match_summary(similarity: SimilarityResult, gaps: dict, passages: list[str]) -> str:
    found = gaps["required_found"]
    missing = gaps["missing_required"]
    if found and missing:
        coverage = f"The resume explicitly mentions {len(found)} required skill(s), while {len(missing)} required skill(s) were not detected."
    elif found:
        coverage = "The resume explicitly mentions all listed required skills detected by this dictionary."
    else:
        coverage = "No listed required skills were detected by the curated dictionary."
    evidence = " Supporting resume evidence is available below." if passages else " No matching resume passage was identified."
    method = "local sentence-transformer embeddings" if similarity.method == "sentence-transformer" else "the transparent lexical fallback"
    return f"Semantic match score: {similarity.score:.2f}/100 using {method}. {coverage}{evidence}"


def analyze_job(resume_text: str, job: dict, model=None) -> dict:
    similarity = compare_texts(resume_text, job.get("description", ""), model=model)
    gaps = skill_gap_analysis(resume_text, job.get("required_skills", ""), job.get("preferred_skills", ""))
    passages = relevant_passages(resume_text, gaps["required_found"] + gaps["preferred_found"])
    return {
        "job_id": job.get("job_id", ""),
        "job_title": job.get("job_title", ""),
        "role_category": job.get("role_category", ""),
        "semantic_similarity_score": similarity.score,
        "similarity_method": similarity.method,
        "raw_cosine": similarity.raw_cosine,
        "resume_skills": gaps["resume_skills"],
        "required_found": gaps["required_found"],
        "missing_required": gaps["missing_required"],
        "preferred_found": gaps["preferred_found"],
        "missing_preferred": gaps["missing_preferred"],
        "relevant_passages": passages,
        "match_summary": build_match_summary(similarity, gaps, passages),
        "job_description": job.get("description", ""),
        "provenance": job.get("provenance", "Synthetic sample data"),
    }


def rank_jobs(resume_text: str, jobs: pd.DataFrame, model=None, similarity_fn: Callable[[str, str], SimilarityResult] | None = None) -> pd.DataFrame:
    """Rank all jobs, preserving transparent skill coverage columns."""
    rows: list[dict] = []
    for _, row in jobs.iterrows():
        job = row.to_dict()
        similarity = similarity_fn(resume_text, job.get("description", "")) if similarity_fn else compare_texts(resume_text, job.get("description", ""), model=model)
        gaps = skill_gap_analysis(resume_text, job.get("required_skills", ""), job.get("preferred_skills", ""))
        rows.append(
            {
                "job_id": job.get("job_id", ""),
                "job_title": job.get("job_title", ""),
                "role_category": job.get("role_category", ""),
                "semantic_similarity_score": similarity.score,
                "similarity_method": similarity.method,
                "required_found_count": len(gaps["required_found"]),
                "required_total": len(gaps["required_found"]) + len(gaps["missing_required"]),
                "missing_required_count": len(gaps["missing_required"]),
                "matching_skills": ", ".join(gaps["required_found"] + gaps["preferred_found"]),
                "missing_required": ", ".join(gaps["missing_required"]),
                "provenance": job.get("provenance", "Synthetic sample data"),
            }
        )
    return pd.DataFrame(rows).sort_values(
        by=["semantic_similarity_score", "required_found_count"], ascending=[False, False]
    ).reset_index(drop=True)
