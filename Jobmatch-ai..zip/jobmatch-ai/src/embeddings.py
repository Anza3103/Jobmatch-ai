"""Lazy local Sentence Transformer loading with a transparent fallback."""

from __future__ import annotations

from functools import lru_cache

from .text_preprocessing import tokenize

DEFAULT_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"


class EmbeddingModelError(RuntimeError):
    """Raised when the configured local model cannot be loaded."""


@lru_cache(maxsize=2)
def load_embedding_model(model_name: str = DEFAULT_MODEL_NAME):
    """Load the model once per process; downloads happen only on first use."""
    try:
        from sentence_transformers import SentenceTransformer
        return SentenceTransformer(model_name)
    except Exception as exc:  # pragma: no cover - depends on network/runtime
        raise EmbeddingModelError(
            "The local embedding model could not be loaded. "
            "Check network access or run with the lexical fallback."
        ) from exc


def encode_texts(texts: list[str], model=None):
    """Encode text using a supplied or lazily loaded Sentence Transformer."""
    if model is False:
        raise EmbeddingModelError("Embedding model disabled; use the lexical fallback.")
    encoder = model or load_embedding_model()
    return encoder.encode(texts, convert_to_numpy=True, normalize_embeddings=True)


def lexical_similarity(text_a: str, text_b: str) -> float:
    """A deterministic, explainable Jaccard fallback scored from 0 to 1."""
    left, right = set(tokenize(text_a)), set(tokenize(text_b))
    if not left or not right:
        return 0.0
    return len(left & right) / len(left | right)
