"""Text normalization helpers used by the matching pipeline."""

from __future__ import annotations

import re
import unicodedata


def normalize_text(text: str | None) -> str:
    """Return readable, lowercase text with normalized whitespace."""
    if not text:
        return ""
    normalized = unicodedata.normalize("NFKC", str(text))
    normalized = normalized.replace("\u00a0", " ")
    normalized = re.sub(r"[\r\n\t]+", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized)
    return normalized.strip().lower()


def clean_for_embedding(text: str | None) -> str:
    """Normalize text while retaining punctuation useful to language models."""
    return normalize_text(text)


def tokenize(text: str | None) -> list[str]:
    """Tokenize normalized text into simple alphanumeric-ish terms."""
    return re.findall(r"[a-z0-9][a-z0-9+#.\-/]*", normalize_text(text))
