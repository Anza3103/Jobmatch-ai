"""Transparent skill matching based on a curated alias dictionary."""

from __future__ import annotations

import re
from collections import OrderedDict

from .text_preprocessing import normalize_text

# Canonical names map to common written aliases. Keep this list small and reviewable.
SKILL_ALIASES: OrderedDict[str, tuple[str, ...]] = OrderedDict(
    {
        "Python": ("python",),
        "SQL": ("sql",),
        "Java": ("java",),
        "C++": ("c++", "cplusplus"),
        "JavaScript": ("javascript", "js"),
        "R": ("r", "r programming", "r language"),
        "Pandas": ("pandas",),
        "NumPy": ("numpy", "num py"),
        "scikit-learn": ("scikit-learn", "sklearn", "scikit learn"),
        "PyTorch": ("pytorch", "torch"),
        "TensorFlow": ("tensorflow", "tf"),
        "NLP": ("nlp", "natural language processing"),
        "RAG": ("rag", "retrieval augmented generation", "retrieval-augmented generation"),
        "embeddings": ("embeddings", "embedding"),
        "transformers": ("transformers", "transformer models"),
        "LLMs": ("llm", "llms", "large language model", "large language models"),
        "computer vision": ("computer vision", "cv"),
        "deep learning": ("deep learning",),
        "machine learning": ("machine learning", "ml"),
        "data analysis": ("data analysis", "data analytics"),
        "statistics": ("statistics", "statistical analysis"),
        "Git": ("git", "github"),
        "Docker": ("docker", "containerization", "containers"),
        "FastAPI": ("fastapi", "fast api"),
        "Streamlit": ("streamlit",),
        "REST APIs": ("rest api", "rest apis", "restful api", "restful apis"),
        "PostgreSQL": ("postgresql", "postgres"),
        "MongoDB": ("mongodb", "mongo db", "mongo"),
        "AWS": ("aws", "amazon web services"),
        "Azure": ("azure",),
        "GCP": ("gcp", "google cloud platform"),
        "Kubernetes": ("kubernetes", "k8s"),
        "airflow": ("airflow", "apache airflow"),
        "Spark": ("spark", "apache spark"),
        "Linux": ("linux",),
        "OpenCV": ("opencv", "open cv"),
        "Plotly": ("plotly",),
        "Excel": ("excel", "microsoft excel"),
        "JSON": ("json",),
        "Power BI": ("power bi",),
        "A/B testing": ("a/b testing", "ab testing", "ab tests"),
        "MLflow": ("mlflow", "ml flow"),
        "Elasticsearch": ("elasticsearch", "elastic search"),
    }
)


def _pattern_for_alias(alias: str) -> re.Pattern[str]:
    escaped = re.escape(alias.lower())
    # Lookarounds avoid matching Java in JavaScript while still handling punctuation.
    return re.compile(rf"(?<![a-z0-9]){escaped}(?![a-z0-9])", re.IGNORECASE)


_ALIAS_PATTERNS = {
    canonical: tuple(_pattern_for_alias(alias) for alias in aliases)
    for canonical, aliases in SKILL_ALIASES.items()
}


def extract_skills(text: str | None) -> set[str]:
    """Return canonical skills explicitly found in text."""
    normalized = normalize_text(text)
    found: set[str] = set()
    for canonical, patterns in _ALIAS_PATTERNS.items():
        if any(pattern.search(normalized) for pattern in patterns):
            found.add(canonical)
    return found


def parse_skill_list(value: str | None) -> list[str]:
    """Parse a semicolon/comma/pipe-delimited dataset skill field."""
    if not value:
        return []
    parts = re.split(r"[;,|]", str(value))
    canonical_by_lower = {skill.lower(): skill for skill in SKILL_ALIASES}
    result: list[str] = []
    for part in parts:
        item = part.strip()
        if not item:
            continue
        result.append(canonical_by_lower.get(item.lower(), item))
    return list(dict.fromkeys(result))


def skill_gap_analysis(resume_text: str, required_skills: str | list[str] | None, preferred_skills: str | list[str] | None) -> dict[str, list[str] | set[str]]:
    """Compare detected resume skills with explicitly listed job skills."""
    required = parse_skill_list(required_skills) if isinstance(required_skills, str) else list(required_skills or [])
    preferred = parse_skill_list(preferred_skills) if isinstance(preferred_skills, str) else list(preferred_skills or [])
    found = extract_skills(resume_text)
    required = list(dict.fromkeys(required))
    preferred = list(dict.fromkeys(preferred))
    return {
        "resume_skills": sorted(found),
        "required_found": [skill for skill in required if skill in found],
        "missing_required": [skill for skill in required if skill not in found],
        "preferred_found": [skill for skill in preferred if skill in found],
        "missing_preferred": [skill for skill in preferred if skill not in found],
    }
