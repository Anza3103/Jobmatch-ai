"""Downloadable, privacy-conscious report builders."""

from __future__ import annotations

import io
import json

import pandas as pd

from .recommendations import generate_recommendations


def build_report(match: dict, include_resume_text: bool = False, resume_text: str = "") -> dict:
    report = {
        "job_title": match.get("job_title", ""),
        "job_id": match.get("job_id", ""),
        "semantic_similarity_score": match.get("semantic_similarity_score", 0.0),
        "similarity_method": match.get("similarity_method", ""),
        "detected_resume_skills": match.get("resume_skills", []),
        "required_skills_detected": match.get("required_found", []),
        "missing_required_skills": match.get("missing_required", []),
        "missing_preferred_skills": match.get("missing_preferred", []),
        "match_explanation": match.get("match_summary", ""),
        "relevant_resume_passages": match.get("relevant_passages", []),
        "improvement_recommendations": generate_recommendations(match),
        "provenance": match.get("provenance", ""),
    }
    if include_resume_text:
        report["resume_text"] = resume_text
    return report


def report_json(match: dict, include_resume_text: bool = False, resume_text: str = "") -> bytes:
    return json.dumps(build_report(match, include_resume_text, resume_text), indent=2, ensure_ascii=False).encode("utf-8")


def report_csv(match: dict, include_resume_text: bool = False, resume_text: str = "") -> bytes:
    report = build_report(match, include_resume_text, resume_text)
    flattened = {key: "; ".join(value) if isinstance(value, list) else value for key, value in report.items()}
    buffer = io.StringIO()
    pd.DataFrame([flattened]).to_csv(buffer, index=False)
    return buffer.getvalue().encode("utf-8")
