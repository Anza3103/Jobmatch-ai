"""Resume file parsing for PDF and DOCX uploads.

Uploaded files are read in memory and are not persisted by this module.
"""

from __future__ import annotations

from io import BytesIO
from pathlib import Path
from typing import BinaryIO


class ResumeParseError(ValueError):
    """Raised when a resume cannot be parsed safely."""


def supported_extension(filename: str | None) -> str:
    """Return the lowercase supported extension, or an empty string."""
    suffix = Path(filename or "").suffix.lower()
    return suffix if suffix in {".pdf", ".docx"} else ""


def _read_bytes(uploaded_file: bytes | bytearray | BinaryIO) -> bytes:
    if isinstance(uploaded_file, (bytes, bytearray)):
        return bytes(uploaded_file)
    if not hasattr(uploaded_file, "read"):
        raise ResumeParseError("The uploaded object is not readable.")
    try:
        if hasattr(uploaded_file, "seek"):
            uploaded_file.seek(0)
        data = uploaded_file.read()
    except Exception as exc:  # pragma: no cover - defensive for Streamlit wrappers
        raise ResumeParseError(f"Could not read the uploaded file: {exc}") from exc
    if not data:
        raise ResumeParseError("The uploaded file is empty.")
    return data


def extract_pdf_text(data: bytes) -> str:
    try:
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
    except ImportError as exc:  # pragma: no cover
        raise ResumeParseError("PDF support requires PyMuPDF.") from exc
    try:
        document = fitz.open(stream=data, filetype="pdf")
        if document.needs_pass:
            document.close()
            raise ResumeParseError("This PDF is password-protected and cannot be read.")
        pages = [page.get_text("text") for page in document]
        document.close()
    except ResumeParseError:
        raise
    except Exception as exc:
        raise ResumeParseError("The PDF is invalid or unreadable.") from exc
    text = "\n".join(pages).strip()
    if not text:
        raise ResumeParseError("No selectable text was found in the PDF.")
    return text


def extract_docx_text(data: bytes) -> str:
    try:
        from docx import Document
    except ImportError as exc:  # pragma: no cover
        raise ResumeParseError("DOCX support requires python-docx.") from exc
    try:
        document = Document(BytesIO(data))
        blocks = [paragraph.text.strip() for paragraph in document.paragraphs if paragraph.text.strip()]
        for table in document.tables:
            for row in table.rows:
                blocks.append(" | ".join(cell.text.strip() for cell in row.cells))
    except Exception as exc:
        raise ResumeParseError("The DOCX file is invalid or unreadable.") from exc
    text = "\n".join(blocks).strip()
    if not text:
        raise ResumeParseError("No text was found in the DOCX file.")
    return text


def extract_text_from_file(uploaded_file: bytes | bytearray | BinaryIO, filename: str | None = None) -> str:
    """Extract text from a PDF or DOCX file-like object."""
    extension = supported_extension(filename or getattr(uploaded_file, "name", ""))
    if not extension:
        raise ResumeParseError("Please upload a PDF or DOCX file.")
    data = _read_bytes(uploaded_file)
    return extract_pdf_text(data) if extension == ".pdf" else extract_docx_text(data)
