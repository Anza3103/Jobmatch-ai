"""Streamlit entry point for JobMatch AI — Semantic Resume Matcher."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from src.embeddings import EmbeddingModelError, load_embedding_model
from src.job_ranker import analyze_job, rank_jobs
from src.recommendations import generate_recommendations
from src.report_generator import report_csv, report_json
from src.resume_parser import ResumeParseError, extract_text_from_file

ROOT = Path(__file__).resolve().parent
JOBS_PATH = ROOT / "data" / "sample_jobs.csv"
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

st.set_page_config(page_title="JobMatch AI", page_icon="JM", layout="wide", initial_sidebar_state="expanded")

st.markdown(
    """
    <style>
    .block-container { padding-top: 2rem; padding-bottom: 3rem; max-width: 1400px; }
    .hero { background: linear-gradient(135deg, #0f766e 0%, #115e59 100%); color: white; padding: 2.2rem 2.4rem; border-radius: 22px; margin-bottom: 1.4rem; }
    .hero h1 { font-size: 2.7rem; margin: 0 0 .45rem 0; letter-spacing: -.04em; }
    .hero p { color: #ccfbf1; max-width: 820px; font-size: 1.05rem; margin: 0; }
    .eyebrow { text-transform: uppercase; letter-spacing: .14em; font-size: .75rem; font-weight: 700; color: #99f6e4; margin-bottom: .5rem; }
    .info-card { border: 1px solid #dbeafe; background: #f8fafc; padding: 1rem 1.2rem; border-radius: 14px; }
    .small-note { color: #475569; font-size: .88rem; }
    div[data-testid="stMetricValue"] { color: #0f766e; }
    </style>
    """,
    unsafe_allow_html=True,
)


def init_state() -> None:
    defaults = {"resume_text": "", "resume_filename": "", "match": None, "ranked": None}
    for key, value in defaults.items():
        st.session_state.setdefault(key, value)


@st.cache_data

def load_jobs() -> pd.DataFrame:
    return pd.read_csv(JOBS_PATH).fillna("")


@st.cache_resource(show_spinner=False)
def cached_model():
    try:
        return load_embedding_model(MODEL_NAME)
    except EmbeddingModelError:
        # False is a deliberate sentinel understood by encode_texts.
        return False


def job_record(row: pd.Series | dict) -> dict:
    values = row.to_dict() if isinstance(row, pd.Series) else dict(row)
    return {key: str(value) if value is not None else "" for key, value in values.items()}


def show_skill_list(title: str, items: list[str], empty_message: str = "None detected") -> None:
    st.markdown(f"**{title}**")
    if items:
        st.write(" · ".join(items))
    else:
        st.caption(empty_message)


def render_match(match: dict, resume_text: str) -> None:
    st.subheader(f"Match analysis · {match['job_title']}")
    score_col, method_col, required_col, missing_col = st.columns(4)
    score_col.metric("Semantic similarity", f"{match['semantic_similarity_score']:.1f}/100")
    method_col.metric("Scoring method", "Embeddings" if match["similarity_method"] == "sentence-transformer" else "Fallback")
    required_col.metric("Required skills found", len(match["required_found"]))
    missing_col.metric("Required skills missing", len(match["missing_required"]))

    if match["similarity_method"] == "lexical-fallback":
        st.warning("The local embedding model was unavailable, so this result uses a transparent token-overlap fallback. Install dependencies and allow the model download for semantic embeddings.")

    st.info(match["match_summary"])
    left, right = st.columns(2)
    with left:
        show_skill_list("Resume skills detected", match["resume_skills"])
        show_skill_list("Required skills detected", match["required_found"])
        show_skill_list("Preferred skills detected", match["preferred_found"])
    with right:
        show_skill_list("Required skills not detected", match["missing_required"], "All listed required skills were detected")
        show_skill_list("Preferred skills not detected", match["missing_preferred"], "All listed preferred skills were detected")
        st.caption("An undetected skill may still be present if the resume wording or curated dictionary does not cover it.")

    st.markdown("#### Evidence from the resume")
    if match["relevant_passages"]:
        for passage in match["relevant_passages"]:
            st.markdown(f"> {passage}")
    else:
        st.caption("No resume passage was selected as evidence.")

    st.markdown("#### Improvement suggestions")
    for suggestion in generate_recommendations(match):
        st.markdown(f"- {suggestion}")

    st.markdown("#### Download report")
    include_resume = st.checkbox("Include original resume text in the report", value=False, key="include_resume_text")
    c1, c2 = st.columns(2)
    c1.download_button("Download JSON", report_json(match, include_resume, resume_text), file_name="jobmatch_report.json", mime="application/json")
    c2.download_button("Download CSV", report_csv(match, include_resume, resume_text), file_name="jobmatch_report.csv", mime="text/csv")


def main() -> None:
    init_state()
    jobs = load_jobs()

    st.markdown(
        """
        <div class="hero">
          <div class="eyebrow">Portfolio project · transparent NLP</div>
          <h1>JobMatch AI</h1>
          <p>Understand how your resume aligns with a job description using local semantic embeddings, explicit skill evidence, and explainable gap analysis.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    with st.sidebar:
        st.header("1 · Add your resume")
        uploaded = st.file_uploader("Upload PDF or DOCX", type=["pdf", "docx"], help="Files are parsed in memory and are not stored by default.")
        if uploaded is not None:
            if uploaded.name != st.session_state.get("resume_filename"):
                try:
                    st.session_state.resume_text = extract_text_from_file(uploaded, uploaded.name)
                    st.session_state.resume_filename = uploaded.name
                    st.session_state.match = None
                    st.session_state.ranked = None
                    st.success("Resume text extracted.")
                except ResumeParseError as exc:
                    st.error(str(exc))
        st.caption("Privacy note: the app does not permanently store uploaded resumes by default. Do not upload sensitive information to an environment you do not trust.")

        st.header("2 · Choose a job")
        input_mode = st.radio("Job description source", ["Sample job dataset", "Paste manually"], horizontal=True)
        selected_job = None
        if input_mode == "Sample job dataset":
            titles = jobs["job_title"].tolist()
            selected_title = st.selectbox("Sample job", titles, index=0)
            selected_job = job_record(jobs.loc[jobs["job_title"] == selected_title].iloc[0])
            st.caption("Synthetic sample data — not real vacancies.")
        else:
            manual_description = st.text_area("Paste a job description", height=210, placeholder="Include responsibilities, required skills, and preferred skills if available.")
            selected_job = {
                "job_id": "MANUAL",
                "job_title": "Manual job description",
                "role_category": "User supplied",
                "required_skills": "",
                "preferred_skills": "",
                "description": manual_description,
                "provenance": "Provided by the user",
            }

        analyze_clicked = st.button("Analyze resume", type="primary", use_container_width=True, disabled=not bool(st.session_state.resume_text.strip()))
        if analyze_clicked:
            if not selected_job.get("description", "").strip():
                st.error("Add a job description before analyzing.")
            else:
                with st.spinner("Comparing resume and job description..."):
                    model = cached_model()
                    st.session_state.match = analyze_job(st.session_state.resume_text, selected_job, model=model)
                    st.session_state.ranked = None

    tabs = st.tabs(["Resume analysis", "Job explorer", "Compare all jobs", "About & methodology"])

    with tabs[0]:
        if st.session_state.resume_text:
            st.subheader("Resume text review")
            st.text_area("Edit extracted text before analysis", value=st.session_state.resume_text, height=250, key="resume_editor")
            if st.button("Use edited resume text", key="save_resume_edit"):
                st.session_state.resume_text = st.session_state.resume_editor
                st.session_state.match = None
                st.session_state.ranked = None
                st.success("Edited text saved for this session.")
            if st.session_state.match:
                render_match(st.session_state.match, st.session_state.resume_text)
            else:
                st.info("Choose a job in the sidebar and click Analyze resume.")
        else:
            st.markdown("### Start with a resume")
            st.write("Upload a PDF or DOCX resume in the sidebar, review the extracted text, and compare it with a synthetic sample job or your own pasted description.")
            c1, c2, c3 = st.columns(3)
            c1.metric("Sample jobs", len(jobs))
            c2.metric("Skill aliases", "30+")
            c3.metric("Paid APIs required", "0")
            st.markdown("#### First-time workflow")
            st.markdown("1. Upload your resume.  2. Review or edit the extracted text.  3. Select a job.  4. Analyze the match.  5. Inspect evidence, gaps, and exportable reports.")

    with tabs[1]:
        st.subheader("Job explorer")
        search = st.text_input("Search titles or skills", placeholder="Try NLP, Python, analytics...")
        category_options = ["All categories"] + sorted(jobs["role_category"].unique().tolist())
        category = st.selectbox("Role category", category_options)
        filtered = jobs.copy()
        if category != "All categories":
            filtered = filtered[filtered["role_category"] == category]
        if search.strip():
            query = search.lower()
            mask = filtered.astype(str).apply(lambda col: col.str.lower().str.contains(query, regex=False)).any(axis=1)
            filtered = filtered[mask]
        st.dataframe(filtered[["job_id", "job_title", "role_category", "required_skills", "preferred_skills", "experience_level"]], use_container_width=True, hide_index=True)
        st.caption("All records are synthetic and included for demonstration and testing only.")

    with tabs[2]:
        st.subheader("Compare one resume with every sample job")
        if not st.session_state.resume_text:
            st.info("Upload a resume first to unlock ranking.")
        else:
            compare_category = st.selectbox("Filter ranking by category", ["All categories"] + sorted(jobs["role_category"].unique().tolist()), key="compare_category")
            compare_jobs = jobs if compare_category == "All categories" else jobs[jobs["role_category"] == compare_category]
            if st.button("Rank sample jobs", type="primary"):
                with st.spinner("Ranking jobs..."):
                    model = cached_model()
                    st.session_state.ranked = rank_jobs(st.session_state.resume_text, compare_jobs, model=model)
            if st.session_state.ranked is not None:
                ranked = st.session_state.ranked.copy()
                st.dataframe(ranked[["job_title", "role_category", "semantic_similarity_score", "required_found_count", "missing_required_count", "matching_skills"]], use_container_width=True, hide_index=True, column_config={"semantic_similarity_score": st.column_config.NumberColumn("Similarity", format="%.2f")})
                try:
                    import plotly.express as px
                    chart = px.bar(ranked.head(10), x="semantic_similarity_score", y="job_title", color="role_category", orientation="h", title="Top ranked sample jobs")
                    chart.update_layout(yaxis={"categoryorder": "total ascending"}, xaxis_title="Similarity score (0–100)", yaxis_title="")
                    st.plotly_chart(chart, use_container_width=True)
                except ImportError:
                    st.bar_chart(ranked.head(10).set_index("job_title")["semantic_similarity_score"])

    with tabs[3]:
        st.subheader("About the method")
        st.markdown(
            """
            **Semantic embeddings.** The default local model, `sentence-transformers/all-MiniLM-L6-v2`, converts the resume and job description into numeric vectors that capture meaning beyond exact keywords. Cosine similarity compares the direction of those vectors, then the result is scaled from 0 to 100 for readability.

            **Skills and evidence.** A small curated dictionary detects explicitly written skills with aliases and word-boundary matching. This makes the result auditable, but it cannot understand every synonym. A missing detection is not proof that a candidate lacks a capability.

            **Interpretation.** The score is a relative semantic similarity measure. It is not the probability of being hired, a qualification decision, or a statistically calibrated measure of candidate suitability. Do not use arbitrary cutoffs to claim that a candidate is qualified.

            **Privacy.** Uploaded files are parsed in memory and are not permanently stored by this app by default. Reports omit the original resume text unless you explicitly select the inclusion checkbox. Review your deployment and hosting settings before uploading sensitive information.

            **Dataset.** The bundled jobs are synthetic records created for demonstration and testing; they are not current vacancies or claims about real employers.
            """
        )
        st.markdown("#### Architecture")
        st.code("Upload → Parse → Review text → Embed → Cosine similarity → Skill gaps → Evidence → Recommendations → Report", language="text")


if __name__ == "__main__":
    main()
